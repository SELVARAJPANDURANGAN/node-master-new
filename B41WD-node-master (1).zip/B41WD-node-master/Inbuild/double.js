// console.log("Hello World");

const double = (num) => num * 2;

// console.log(process.argv, process.argv[0]);
const [, , n] = process.argv;

console.log(double(n));

// console.log(document);
// console.log(window);
// console.log(global);
